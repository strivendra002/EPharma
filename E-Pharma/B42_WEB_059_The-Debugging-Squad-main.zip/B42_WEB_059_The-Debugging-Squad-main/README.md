# B42_WEB_059_The-Debugging-Squad
Block42 construct week
